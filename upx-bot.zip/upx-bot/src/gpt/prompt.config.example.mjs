export function getPrompt({description}){
	return `
"
${description}
"`
}