import os

while True:
    try:
        os.system('node "login&___.js"')
    except Exception:
        pass